/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guia10ej4;

import Service.PeliculaService;

/**
 *
 * @author joel
 */
public class Guia10Ej4 {

    public static void main(String[] args) {
        PeliculaService peliS = new PeliculaService();
        
        peliS.crearPeliculas();
        
        peliS.mostrarDuracionDesc();
        peliS.mostrarDuracionMayorAsc();
        peliS.mostrarMasUnaHora();
        peliS.mostrarOrdenadaDirector();
        peliS.mostrarOrdenadaTitulo();
    }
}
