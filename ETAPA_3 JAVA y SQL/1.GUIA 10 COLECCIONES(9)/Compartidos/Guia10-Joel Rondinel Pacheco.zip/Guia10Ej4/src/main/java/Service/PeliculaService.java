/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Comparadores.Comparadores;
import Entidad.Pelicula;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author joel
 */
public class PeliculaService {

    private Scanner leer, leerD;
    private ArrayList<Pelicula> peliculas;

    public PeliculaService() {
        this.peliculas = new ArrayList<>();
        this.leer = new Scanner(System.in).useDelimiter("\n");
        this.leerD = new Scanner(System.in).useDelimiter("\n");
    }

    public void crearPeliculas() {
        boolean seguir = true;
        do {
            System.out.println("Ingrese el titulo de la pelicula ");
            String titulo = leer.next();
            System.out.println("Ingrese el director de la pelicula ");
            String director = leer.next();
            System.out.println("Ingrese la duracion de la pelicula");
            Double duracion = leerD.nextDouble();
            Pelicula peli = new Pelicula(titulo, director, duracion);
            peliculas.add(peli);
            System.out.println("---------------");
            System.out.println("Desea agregar otra pelicula? Si/No");
            String otra = leer.next();
            if (otra.equalsIgnoreCase("no")) {
                seguir = false;
            }

        } while (seguir);
    }


    public void mostrarMasUnaHora() {
        System.out.println("Mostrar peliculas con duracion mayor a 1 hora: ");
        for (Pelicula peli : peliculas) {
            if (peli.getDuracion() > 1) {
                mostrar(peli);
            }
        }
    }

    public void mostrarDuracionDesc() {
        System.out.println("Mostrar peliculas de mayor a menor duracion");
        ArrayList<Pelicula> ordenada = duplicar();
        Collections.sort(ordenada, Comparadores.ordenarPorDuracionDesc);
        for (Pelicula peli : ordenada) {
            mostrar(peli);
        }
    }
    
    public void mostrarDuracionMayorAsc() {
        System.out.println("Mostrar peliculas de menor a mayor duracion");
        ArrayList<Pelicula> ordenada = duplicar();
        Collections.sort(ordenada, Comparadores.ordenarPorDuracionAsc);
        for (Pelicula peli : ordenada) {
            mostrar(peli);
        }
    }
    public void mostrarOrdenadaTitulo() {
        System.out.println("Mostrar peliculas ordenadas alfabeticamente por su titulo");
        ArrayList<Pelicula> ordenada = duplicar();
        Collections.sort(ordenada, Comparadores.ordenarPorTitulo);
        for (Pelicula peli : ordenada) {
            mostrar(peli);
        }
    }
    
    public void mostrarOrdenadaDirector() {
        System.out.println("Mostrar peliculas ordenadas alfabeticamente por su director");
        ArrayList<Pelicula> ordenada = duplicar();
        Collections.sort(ordenada, Comparadores.ordenarPorDirector);
        for (Pelicula peli : ordenada) {
            mostrar(peli);
        }
    }


    public void mostrar(Pelicula peli) {
        System.out.println("Titulo: " + peli.getTitulo());
        System.out.println("Director: " + peli.getDirector());
        System.out.println("Duracion: " + peli.getDuracion());
        System.out.println("----------------");
    }
    
    public ArrayList<Pelicula> duplicar(){
        return (ArrayList<Pelicula>) peliculas.clone();
    }

}
