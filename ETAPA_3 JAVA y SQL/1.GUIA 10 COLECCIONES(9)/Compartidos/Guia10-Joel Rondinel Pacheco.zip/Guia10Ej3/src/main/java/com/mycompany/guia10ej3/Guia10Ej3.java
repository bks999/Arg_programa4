/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guia10ej3;

import Service.AlumnoService;

/**
 *
 * @author joel
 */
public class Guia10Ej3 {

    public static void main(String[] args) {
        AlumnoService alumnos = new AlumnoService();
        
        alumnos.crearAlumnos();
        
        alumnos.buscarAlumno("joel");
    }
}
