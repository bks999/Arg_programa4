/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entidad.Alumno;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author joel
 */
public class AlumnoService {

    ArrayList<Alumno> alumnos;
    //Iterator todos;

    public AlumnoService() {
        alumnos = new ArrayList<>();
        //todos = alumnos.iterator();
    }
    
    
    
    Scanner leer = new Scanner(System.in);
    Scanner leer2 = new Scanner(System.in);

    public void crearAlumnos() {
        boolean seguir = true;

        do {
            Alumno alumno = new Alumno();
            System.out.println("Ingrese el nombre");
            alumno.setNombre(leer.nextLine());
            System.out.println("Ingrese las notas");
            ArrayList<Integer> nuevasNotas = new ArrayList<>();
            System.out.println("Antes del for las notas son" + alumno.getNotas());
            for (int i = 0; i < 3; i++) {
                int nota = leer2.nextInt();
                nuevasNotas.add(nota);
//alumno.getNotas().add(nota);
                //System.out.println("En la nota " + i + " las notas son " + alumno.getNotas());
            }
            alumno.setNotas(nuevasNotas);
            
             alumnos.add(alumno);
            System.out.println("Quiere crear otro alumno? Si/No");
            String crear = leer.nextLine();
            if (crear.equalsIgnoreCase("no")) {
                seguir = false;
            }    
        } while (seguir);

    }

    public void buscarAlumno(String nombre){
        for (Alumno alumno : alumnos){
            if (alumno.getNombre().equalsIgnoreCase(nombre)){
                Integer promedio = notaFinal(alumno);
                System.out.println("La nota final del alumno " + nombre + " es: " + promedio);
            }
        }
    }
    
    public Integer notaFinal(Alumno alu){
        Integer promedio = 0;
        for(Integer nota : alu.getNotas()){
            promedio = promedio + nota;
        }
        return (promedio/(3));
        
    }

}
