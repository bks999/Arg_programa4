/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidad;

import java.util.Objects;

/**
 *
 * @author joel
 */
public class Paises implements Comparable<Paises>{
    
    private String pais;
    
    public Paises(){
        
    }
    
    public Paises(String pais){
        this.pais = pais;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }  

    @Override
    public int compareTo(Paises t) {
        return this.pais.compareTo(t.getPais());
    }

    @Override
    public String toString() {
        return pais;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.pais);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Paises other = (Paises) obj;
        return Objects.equals(this.pais, other.pais);
    }
    
    
}
