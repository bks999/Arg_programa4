/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.guia10ej5;

import Entidad.Paises;
import Service.PaisesService;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author joel
 */
public class Guia10Ej5 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        PaisesService serv = new PaisesService();
        Set<Paises> paisesHash = new HashSet<>();

        boolean seguir = true;
        do {
            Paises nuevo;
            nuevo = serv.agregarPais();
            paisesHash.add(nuevo);
            System.out.println("Desea agregar otro pais? Si/No");
            String agregar = leer.nextLine();
            if (agregar.equalsIgnoreCase("no")) {
                seguir = false;
                serv.mostrarPaises(paisesHash);
                serv.ordenarPaises(paisesHash);
            }
        } while (seguir);
        
        System.out.println("Ingrese un pais");
        String paisN = leer.nextLine();
        serv.buscarPais(paisN, paisesHash);
    }
}
