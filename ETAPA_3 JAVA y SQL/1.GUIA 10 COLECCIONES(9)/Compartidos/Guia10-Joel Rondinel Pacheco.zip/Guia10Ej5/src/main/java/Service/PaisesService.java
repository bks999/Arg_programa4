/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entidad.Paises;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author joel
 */
public class PaisesService{

    private Scanner leer;
    
    public PaisesService() {
        this.leer = new Scanner(System.in);
    }

    public Paises agregarPais() {
            System.out.println("Ingrese el pais");
            String pais1 = leer.nextLine();
            Paises pais = new Paises(pais1);
            return pais;            
    }
    
    public void mostrarPaises(Set<Paises> paises){
        System.out.println("Sin ordenar");
        for (Paises pais : paises){
            System.out.println("Pais: " + pais.getPais());
        }
    }
    
    public void ordenarPaises(Set<Paises> paises){
        System.out.println("Ordenados");
        Set<Paises> paisesOrdenados = new TreeSet(paises);
        for(Paises pais : paisesOrdenados){
            System.out.println("Pais: " + pais.getPais());
        }
    }


    public void buscarPais(String pais, Set<Paises> paises){
        Iterator it = paises.iterator();
        boolean noborro = true;
        while(it.hasNext()){
            if(it.next().toString().equalsIgnoreCase(pais)){
               it.remove();
               noborro = false;
            }       
        }
        if(noborro){
            System.out.println("No se enctro el pais en la lista");
        }
        System.out.println("Despues de borrar (o no)");
        mostrarPaises(paises);
    }
}
