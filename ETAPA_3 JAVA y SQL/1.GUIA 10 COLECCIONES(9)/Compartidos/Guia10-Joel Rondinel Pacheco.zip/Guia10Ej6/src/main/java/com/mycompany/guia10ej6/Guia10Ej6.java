/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guia10ej6;

import Service.ProductoService;

/**
 *
 * @author joel
 */
public class Guia10Ej6 {

    public static void main(String[] args) {
        ProductoService serv = new ProductoService();
        serv.menu();
    }
}
