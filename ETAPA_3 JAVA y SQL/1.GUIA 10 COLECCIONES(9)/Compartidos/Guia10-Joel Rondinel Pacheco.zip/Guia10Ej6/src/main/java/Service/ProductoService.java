/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author joel
 */
public class ProductoService {

    private Scanner leer;
    private Scanner leerD;
    private Scanner leerI;
    private HashMap<String, Double> productos;

    public ProductoService() {
        this.leer = new Scanner(System.in);
        this.leerD = new Scanner(System.in);
        this.leerI = new Scanner(System.in);
        productos = new HashMap();
    }

    public void nuevoProducto() {
        System.out.println("Ingrese el nombre del producto");
        String nombre = leer.nextLine();
        System.out.println("Ingrese el precio");
        double precio = leerD.nextDouble();
        productos.put(nombre, precio);
    }

    public void modificarPrecio() {
        System.out.println("Ingrese el producto del que desea modificar el precio:");
        String prod = leer.nextLine();
        System.out.println("Ingrese el precio nuevo");
        double prec = leerD.nextDouble();
        productos.replace(prod, prec);
    }

    public void eliminarProducto() {
        System.out.println("Ingrese el producto del que desea eliminar:");
        String prod = leer.nextLine();
        productos.remove(prod);
    }

    public void mostrarProductos() {
        for (Map.Entry<String, Double> aux : productos.entrySet()) {
            String prod = aux.getKey();
            Double precio = aux.getValue();
            System.out.println("El producto: " + prod + " tiene un precio de: " + precio);
        }
    }

    public void menu() {
        boolean seguir = true;
        do {
            System.out.println("Ingrese que accion desea realizar");
        System.out.println("Ingresar un nuevo producto = 1");
        System.out.println("Modificar el precio de un producto = 2");
        System.out.println("Eliminar un producto = 3");
        System.out.println("Mostrar todos los productos = 4");
        System.out.println("Salir = 5");
            int opcion = leerI.nextInt();
            switch (opcion) {
                case 1:
                    nuevoProducto();
                    System.out.println("---------------------------");
                    break;
                case 2:
                    modificarPrecio();
                    System.out.println("---------------------------");
                    break;
                case 3:
                    eliminarProducto();
                    System.out.println("---------------------------");
                    break;
                case 4:
                    mostrarProductos();
                    System.out.println("---------------------------");
                    break;
                case 5:
                    System.out.println("---------------------------");
                    System.out.println("Programa finalizado");
                    seguir = false;
                    break;
                default:
                    System.out.println("Ingrese una opcion valida");

            }

        } while (seguir);
    }
}
