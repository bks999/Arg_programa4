/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entidad.Mascota;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author joel
 */
public class MascotaService {

    private Scanner leer = new Scanner(System.in);

    public Mascota crearMascota() {
        Mascota mascota = new Mascota();
        return mascota;
    }

    public void crearRazas(Mascota razas) {
        System.out.println("Ingrese la raza del perro");
        String raza = leer.nextLine();
        razas.getRazas().add(raza);
    }

    public void agregarRazas(Mascota razas) {
        boolean seguir = true;
        String agregar;
        do {
            crearRazas(razas);
            System.out.println("Quiere agregar otra raza? Si/No");
            agregar = leer.nextLine();
            if (agregar.equalsIgnoreCase("no")) {
                seguir = false;
                mostrarLista(razas);

                System.out.println("Ingrese una raza a eliminar");
                String perro = leer.nextLine();
                Iterator it = razas.getRazas().iterator();
                int cantPerros = 0;
                while (it.hasNext()) {
                    if (it.next().equals(perro)) {
                        it.remove();
                        System.out.println("Se elimino");
                        cantPerros = cantPerros +1;
                    }
                }
                if(cantPerros == 0) {
                    System.out.println("No lo encontro en la lista");
                }
                
                mostrarLista(razas);
                System.out.println("Ordena");
                ordenarLista(razas);

                mostrarLista(razas);

            }

        } while (seguir);

    }

    public void mostrarLista(Mascota razas) {
        for (String raza : razas.getRazas()) {
            System.out.println("raza: " + raza);
        }
    }

    public void ordenarLista(Mascota razas) {
        Collections.sort(razas.getRazas());
    }

}
