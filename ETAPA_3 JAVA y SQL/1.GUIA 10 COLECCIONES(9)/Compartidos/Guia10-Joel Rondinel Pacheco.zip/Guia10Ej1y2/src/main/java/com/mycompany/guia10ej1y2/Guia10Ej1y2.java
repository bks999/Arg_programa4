/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.guia10ej1y2;

import Entidad.Mascota;
import Service.MascotaService;

/**
 *
 * @author joel
 */
public class Guia10Ej1y2 {

    public static void main(String[] args) {
        
        MascotaService servMas = new MascotaService();
        
        Mascota mascota = servMas.crearMascota();
        
        servMas.agregarRazas(mascota);
       
        
      
    }
}
